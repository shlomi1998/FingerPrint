
import pandas as pd
import pymysql
pymysql.install_as_MySQLdb()

# Open database connection
#db = MySQLdb.connect(
db = pymysql.connect(
    host="localhost",
    user="root",
    passwd="1234",
    db="db1"
   )

print(f"DB is: {db}")
cursor = db.cursor()


"""

"""
def close_db():
    func_name = "close_db"
    #print(f"In {func_name}")

    global db
    db.close()


def find_date(date):
    func_name = "find_date"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Date="{date}" AND users.ID=fingerprint.IdUser ;'

    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print("Could not find Date")
        else:
            print(f"Found date: {date}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def find_hand(hand):
    func_name = "find_hand"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Hand="{hand}" AND users.ID=fingerprint.IdUser ;'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print("Could not find Hand")
        else:
            print(f"Found hand: {hand}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


##################################################
def find_finger(finger):
    func_name = "find_finger"
    #print(f"In {func_name}")

    global db

    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Finger={finger} AND users.ID=fingerprint.IdUser ;'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print("Could not find Finger")
        else:
            print(f"Found finger {finger}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def find_finger_and_hand(hand, finger):
    func_name = "find_finger_and_hand"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Finger={finger} AND fingerprint.Hand="{hand}" AND users.ID=fingerprint.IdUser ;'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print("Could not find Hand and Finger")
        else:
            print(f"Found hand {hand} and finger {finger}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_full_name_by_id(id):
    func_name = "get_full_name_by_id"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT FirstName, LastName FROM users' \
          f' WHERE users.ID={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()
        if res == ():
            print("Could not find user's full name")
            return None
        else:
            print(f"Found id: {id}\n")
            print(f"Result from DB: {res}")
            db.commit()  # Commit changes to database
            return res[0][0], res[0][1]
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_first_name(id):
    func_name = "get_first_name"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT FirstName FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()
        if res == ():
            print("Could not find First name")
            return None
        else:
            print(f"Found id: {id}\n")
            print(f"Result from DB: {res}")
            db.commit()  # Commit changes to database
            return res[0][0]
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_last_name(id):
    func_name = "get_last_name"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT LastName FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()
        if res == ():
            print("Could not find Last name")
            return None
        else:
            print(f"Found id {id}:\n")
            print(f"Result from DB: {res}")
            db.commit()  # Commit changes to database
            return res[0][0]
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def find_id(id):
    func_name = "find_id"
    #print(f"In {func_name}")

    global db

    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()
        if res == ():
            print("Could not find ID")
        else:
            print(f"Found id {id}:\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def delete_fingerprint(id):
    func_name = "delete_fingerprint"
    #print(f"In {func_name}")

    global db
    sql = f'DELETE FROM  db1.fingerprint WHERE IdUser={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def delete_user(id):
    func_name = "delete_user"
    #print(f"In {func_name}")

    global db
    delete_fingerprint(id)
    sql = f'DELETE FROM db1.users WHERE ID={id};'
    try:
        cursor.execute(sql)  # execute SQL command
        print(f"user id={id} delete")
        db.commit()  # commit changes to database
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def create_user(id, first_name, last_name, gender):
    func_name = "create_user"
    #print(f"In {func_name}")

    global db
    sql = f'INSERT INTO db1.users (ID, FirstName,LastName, Gender) VALUES  ("{int(id)}","{first_name}", "{last_name}","{gender}")'

    try:
        cursor.execute(sql)  # execute SQL command
        db.commit()  # commit changes to database
        print("New user created\n")
        return True
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")
        return False


def add_fingerprint(iduser, hand, finger, date, time, link, details, interesting_points):
    func_name = "add_fingerprint"
    #print(f"In {func_name}")

    global db
    sql = f'INSERT INTO db1.fingerprint (IdUser, Hand, Finger, Date, Time, ' \
        f'LinkImage, Details, InterestingPoints)' \
        f' VALUES ("{iduser}", "{hand}", "{finger}", "{date}", "{time}", "{link}", "{details}", "{interesting_points}")'

    try:
        cursor.execute(sql)  # execute SQL command
        db.commit()  # Commit changes to database
        return True
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")
        return False


def print_all_users():
    func_name = "print_all_users"
    #print(f"In {func_name}")

    num_row = cursor.execute('SELECT * FROM db1.users')
    print(num_row)
    results = cursor.fetchall()
    for row in results:
        id = row[0]
        first_name = row[1]
        last_name = row[2]
        gender = row[3]
        # hand = row[4]
        # finger = row[5]
        # data = row[6]
        # time = row[7]
        # code = row[8]
        # Now print fetched result
        print(f'id ={id}, first_name={first_name}, last_name={last_name}, gender={gender}\n')
        # , hand = {hand}, finger = {finger}, data = {data}, time = {time}, code = {code}\n
        # ')


def save_tables_in_excel():
    func_name = "save_tables_in_excel"
    #print(f"In {func_name}")

    file_name = 'save_db.xlsx'

    with pd.ExcelWriter(file_name) as writer:
        sql = 'SELECT * FROM db1.users'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer, sheet_name='users')
        # ------------------------
        sql = 'SELECT * FROM db1.fingerprint'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer, sheet_name='fingerprint')
        # ------------------------
        sql = 'SELECT * FROM db1.user_relationships'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer, sheet_name='user_relationships')
    # ------------------------
    print("DB saved in excel")


def get_all_fingerprints():
    func_name = "get_all_fingerprints"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT IdUser, LinkImage FROM fingerprint;'
    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print(f"Could not find fingerprints\n")
        else:
            print("Found all fingerprints\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
        return res
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_userid_by_linkimage(link_image):
    func_name = "get_userid_by_linkimage"
    #print(f"In {func_name}")

    global db
    image_name = link_image.split('/')
    image_name = '/'.join(part for part in image_name)
    print("Image name: ", image_name)
    sql = f'SELECT IdUser FROM db1.fingerprint' \
          f' WHERE fingerprint.LinkImage="{image_name}";'

    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print(f"Could not find users' ids\n")
        else:
            print(f"Found user's id that match to {link_image}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
        return res
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_userid_by_hand_and_finger(hand, finger):
    func_name = "get_userid_by_hand_and_finger"
    #print(f"In {func_name}")

    global db
    #image_name = link_image.split('/')
    #image_name = '/'.join(part for part in image_name)
    #print("Image name: ", image_name)
    sql = f'SELECT IdUser, LinkImage ' \
        f'FROM db1.fingerprint ' \
          f'WHERE db1.fingerprint.Hand="{hand}" AND db1.fingerprint.Finger="{finger}";'

    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print(f"Could not find users' ids\n")
        else:
            print(f"Found user's id that match to hand: {hand}, finger: {finger}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
        return res
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")


def get_interesting_points_by_id(id, hand, finger):
    func_name = "get_interesting_points_by_id"
    #print(f"In {func_name}")

    global db
    sql = f'SELECT InterestingPoints ' \
        f'FROM db1.fingerprint ' \
          f'WHERE db1.fingerprint.IdUser={id} AND db1.fingerprint.Hand="{hand}" AND db1.fingerprint.Finger="{finger}";'

    try:
        cursor.execute(sql)  # execute SQL command
        res = cursor.fetchall()

        if res == ():
            print(f"Could not find user's interesting points\n")
        else:
            print(f"Found user's interesting points that match to hand: {hand}, finger: {finger}\n")
            print(f"Result from DB: {res}")
        db.commit()  # commit changes to database
        return res
    except Exception as e:
        print(f"Error in {func_name}: {str(e)}")






# prepare a cursor object using cursor() method

# print(type(num_row))
# add_to_db(db,'22222222',"avi", 'levi', 'm', 'r', '4', '2019-06-04','13:10:00','333')
# add_to_db(db,'12345678', 'noa', 'levi', 'f', 'r', '4', '2019-06-04','18:10:00','222')


# create_user('55555', 'sdfg', 'levi', 'female')
# delete_user('55555')
# add_fingerprint(db,'2222','l', '1', '2019-06-04','18:10:00','','')
# find_finger(db,'4')
# find_hand(db,'r')
# find_id(db,'206221293')
# print_all_users()
# save_tabels_in_excel()
# delete_user(db,'2
# 222')
# find_hand(db,"l")
# find_finger_and_hand('r','4')
# #
# find_id("206221293")



# find_date(db,datetime.date(2019, 6, 4))

# print(datetime.date(2019, 6, 4))

# disconnect from server
# print(get_last_name('206221293'))




