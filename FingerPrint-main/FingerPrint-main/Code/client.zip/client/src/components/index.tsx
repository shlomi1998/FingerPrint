import ImageRecognition from "./ImageRecognition"

export {ImageRecognition}