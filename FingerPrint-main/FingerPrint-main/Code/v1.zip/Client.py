#!/usr/bin/env python

"""
This file defines the client side of Fingerprint project.

Author: Ayelet Zadock
Last modified: 05-05-2019

"""

# Imports:
import os
import glob
import cv2
import numpy as np
import pandas as pd
# import tkinter.filedialog as tk # or
from tkinter import filedialog
import globalFunctions as gf
from globalFunctions import *
# from pyimagesearch.panorama import Stitcher
import argparse
import imutils
from stitch import Stitcher
from PIL import Image, ImageChops

import time
import scipy.misc


# Globals:
constants = gf.CONSTANT()
FLOAT_TYPE_STR = constants.FLOAT_TYPE_STR
IMG_TIF_TYPE = constants.IMG_TIF_TYPE
IMG_JPG_TYPE = constants.IMG_JPG_TYPE
STAR = constants.STAR
ZERO = constants.ZERO
SCALE = constants.SCALE
OFFSET = constants.OFFSET


'''
Function name: trim()

Brief: Function to crop black border from a PIL image.

Description:
This function gets a PIL image and removes its border.

Input:
    - image (Image): a PIL image.
Output:
    - croppedImg (Image): a cropped PIL image.

Errors and exceptions:
    - If didn't succeed to find positions to crop, return input image (image). 

'''

def trim(image):
    bg = Image.new(image.mode, image.size, image.getpixel((ZERO, ZERO)))  # create a new black image
    diff = ImageChops.difference(image, bg)  # calculates absolute value of the difference between the two pix-by-pix
    diff = ImageChops.add(diff, diff, scale=SCALE,
                          offset=-OFFSET)  # adds diff to diff, divides the result by scale and adds the offset
    bbox = diff.getbbox()  # get positions to crop
    if bbox:
        croppedImg = image.crop(bbox)  # crops image by positions that found before
        return croppedImg
    return image  # if didn't succeed to find positions to crop


def mse(imageA, imageB):
    # the 'Mean Squared Error' between the two images is the
    # sum of the squared difference between the two images;
    # NOTE: the two images must have the same dimension
    err = np.sum((imageA.astype(FLOAT_TYPE_STR) - imageB.astype(FLOAT_TYPE_STR)) ** 2)
    shape_size = imageA.shape[0] * imageA.shape[1]
    err /= float(shape_size)

    # return the MSE, the lower the error, the more "similar"
    # the two images are
    return err


def mseUpdated(imageA, imageB):
    # the 'Mean Squared Error' between the two images is the
    # sum of the squared difference between the two images;
    # NOTE: the two images must have the same dimension
    diff = [imageA.astype(FLOAT_TYPE_STR) - imageB.astype(FLOAT_TYPE_STR)]
    print("diff: ", diff)
    err = np.sum((imageA.astype(FLOAT_TYPE_STR) - imageB.astype(FLOAT_TYPE_STR)) ** 2)
    shape_size = imageA.shape[0] * imageA.shape[1]
    err /= float(shape_size)

    # return the MSE, the lower the error, the more "similar"
    # the two images are
    return err


def cleanImage(img, range_start=ZERO, range_stop=256):
    pixels = {i: np.sum(img == i) for i in
              range(range_start, range_stop)}  # build a dictionary that counts amount of pixels per color
    max_value = max(pixels.values())

    '''
    max_value_of_color = range_stop
    for i in range(range_stop - 1, range_start + 1, -1):
        if pixels[i] != 0:
            max_value_of_color = i
            break

    smallest = img.min(axis=0).min(axis=0)
    max_value_of_color = img.max(axis=0).max(axis=0)

    img = img * (255/max_value_of_color)
    '''
    factor = 255 / max_value
    print("--------------------")
    print("img: ", img)
    print("********************")
    img = img + factor
    #img = img / max_value
    #img = img * 255
    return img


def findThresholdByRange(img, range_start=ZERO, range_stop=256):
    pixels = {i: np.sum(img == i) for i in
              range(range_start, range_stop)}  # build a dictionary that counts amount of pixels per color
    max_value = max(pixels.values())
    max_list = [key for key in pixels if pixels[key] == max_value]
    threshold = int(sum(max_list) / len(max_list))
    threshold = min(max_list)
    return threshold


def findThreshold(img, range_start=ZERO, range_stop=256):
    threshold = findThresholdByRange(img, range_start, range_stop)
    # if threshold in [0, 255]:
    # threshold = findThresholdByRange(img, 1, 255)
    #    threshold = 138
    # return None
    print("Threshold is {}".format(threshold))

    if threshold is not None:
        ret2, thresh_img = cv2.threshold(img, threshold - 1, 255, cv2.THRESH_BINARY)
    else:
        thresh_img = img

    return thresh_img


def findMatchByMSE_Threshold(source_img, DBpath=gf.DBpath):
    kernel = np.ones((5, 5), np.uint8)
    i = ZERO
    is_continue = False

    match_img_list = []

    thresh_source_img = findThreshold(source_img)  # find threshold of source image

    print("Path: " + DBpath)

    for filename in glob.glob(os.path.join(DBpath, STAR + IMG_TIF_TYPE)):
        print("Filename: ", filename)
        dest_img = cv2.imread(filename)  # read a new image
        ###dest_img = cv2.morphologyEx(dest_img, cv2.MORPH_CLOSE, kernel)  # clean image by morphology method
        mse_before_threshold = mse(source_img, dest_img)  # calculate MSE function
        print("MSE before threshold: ", mse_before_threshold)

        thresh_dest_img = findThreshold(dest_img)  # find threshold of current image in DB
        mse_after_threshold = mse(thresh_source_img, thresh_dest_img)  # calculate MSE function
        print("MSE after threshold: ", mse_after_threshold)

        print("index: ", i, "\n")
        i += 1
        if i > 6:  # if condition to break loop due to runtime
            break
        print("----------------------------------------------")

        if mse_before_threshold < gf.THRESHOLD:
            match_img_list.append(dest_img)  # thresh_dest_img

        continue  # break current iteration -prevents error of open-cv

    ###This if-else loop should be fixed!!!
    if len(match_img_list) < 1:  # if there is no match
        is_continue = bool(input("No match was found by MSE, do you want to continue?"))
    else:  # if found at least one image that may be matches

        if is_continue:
            match_img_list = glob.glob(os.path.join(DBpath, STAR + IMG_TIF_TYPE))

        matchList = []  # define a list for matches, if will be
        stitcher = Stitcher()  # define a variable of Stitcher class
        i = 0

        final_match_img = []

        for match_img in match_img_list:
            imagesList = [source_img, match_img]  # thresh_source_img  # define a list of source and destination images to stitch
            # if mse_after_threshold-mse_before_threshold <= 0:
            # stitch the images together to create a panorama
            (result, vis) = stitcher.stitch(imagesList, showMatches=True)
            # else:
            #    result = None

            if not (result is None):  # if succeed to find matches between the two images
                print("Match was found.")
                final_match_img.append(match_img)
                # cv2.imshow("VIS", vis)
                scipy.misc.imsave(f'vis_{i}' + IMG_JPG_TYPE, vis)
                i += 1
                # cv2.imshow("result", result)  # show result image (for check)
                img = Image.fromarray(result, 'RGB')
                # img.show()
                img2 = trim(img)
                # img2.show()
                # cv2.waitKey(0)
                matchList.append(filename)  # add filename to matches list
            else:
                print("There are not enough matches.")

        print(f"\nFound {len(final_match_img)} matches as follow:")
        for img_name in final_match_img:
            print(img_name)





def main():
    filename = filedialog.askopenfilename()  # open a dialog to get a path to image file
    fingerprint = gf.getInputImage(filename)  # convert the path into strings data
    [imgFilename, imgDir, imgPath, imgPrefix] = fingerprint  # extract file data
    fingerdata = gf.extractFingerDataFromFilename(imgPrefix)  # convert finger data and extract

    [person, hand, finger, inStandard] = fingerdata  # extract finger data

    filePath = imgPath + imgFilename
    source_img = cv2.imread(filePath)  # read source file from path
    print("Filename: " + filePath)

    DBpath = gf.DBpath  # get DB path from globalFunctions file
    findMatchByMSE_Threshold(source_img)


if __name__ == '__main__':
    start_time = time.time()
    main()
    print("Run time: --- %s seconds ---" % (time.time() - start_time))
