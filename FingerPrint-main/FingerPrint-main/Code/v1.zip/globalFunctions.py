#!/usr/bin/env python

"""
This file defines global functions for Fingerprint project.

Author: Ayelet Zadock
Last modified: 28-05-2018

"""

# Imports:
import os
import glob
import cv2
import pandas as pd
#import tkinter.filedialog as tk # or
from tkinter import filedialog
import ntpath

global DBpath, excelDB, DBsheet

DBpath = os.getcwd() + os.sep + 'database' + os.sep + 'FFP0519'
#DBpath = 'C:/database/'
excelDB = 'database.xlsx'
DBsheet = 'fingerprints'
THRESHOLD = 30000

"""
def getInputImage(inputPath)
Brief: This function gets a path to image and extracts it into filename, file path and file prefix.

Input:
    -inputPath: a path to file.
Output:
    -_inputName: filename.
    -_inputDirName: filename directory name (father).
    -_inputDirPath: directory path.
    -_inputPrefix: filename prefix.
"""
def getInputImage(inputPath):
    # prompts for an image file, and returns the filename, father directory, path, and input prefix
    _inputFileName = ntpath.basename(inputPath)
    _inputDirPath = inputPath[:-len(_inputFileName)]
    _inputDirName = ntpath.basename(_inputDirPath[:-1])
    _dotPos = _inputFileName.rfind('.')
    if _dotPos == -1:  # if there is not a dot in file's name
        _inputFilePrefix = _inputFileName
    else:
        _inputFilePrefix = _inputFileName[:_dotPos]  # assumes that a suffix exists

    return [_inputFileName, _inputDirName, _inputDirPath, _inputFilePrefix]


"""
def extractFingerDataFromFilename(filename)
Brief: This function gets a filename and extracts data of: person name, hand and finger in hand.

Exceptions:
    -Hand should be right(R) or left (L).
    -Finger should be a number between 1-5 while: thumb is 1 and pinkie is 5.
    Otherwise (for both), a variable called _inStandard is changed to be False.

Input:
    -filename: a prefix of filename.
Output:
    -__person: person id.
    -_hand: hand letter.
    -_finger: finger number.
    -_inStandard: a variable that returns True/False. Means, in standard or not.
"""
def extractFingerDataFromFilename(filename):
    _inStandard = True
    _hand = filename[-2]
    _finger = filename[-1]
    if _hand not in 'RL' or _finger not in '12345':
        _inStandard = False
    _handPos = filename.rfind(_hand)
    _person = filename[:_handPos]

    return [_person, _hand, _finger, _inStandard]


class CONSTANT(object):
    FLOAT_TYPE_STR = "float"
    IMG_TIF_TYPE = '.tif'
    IMG_JPG_TYPE = '.jpg'
    STAR = '*'
    ZERO = 0
    SCALE = 2.0
    OFFSET = 100
