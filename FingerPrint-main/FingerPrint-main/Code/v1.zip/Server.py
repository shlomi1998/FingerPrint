import mysql.connector# as sql

db = mysql.connector.connect()
print(db)
