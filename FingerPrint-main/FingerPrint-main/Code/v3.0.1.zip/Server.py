
from stitch import Stitcher
import mysql
import PIL
from Client import *
from PIL import Image, ImageTk, ImageEnhance,ImageFilter
import numpy

def findMatchByMSE_Threshold(source_img, dbPath=DBpath):
    kernel = np.ones((5, 5), np.uint8)
    i = ZERO
    is_continue = False

    match_img_list = []

    thresh_source_img = findThreshold(source_img)  # find threshold of source image

    print("Path: " + dbPath)

    for filename in glob.glob(os.path.join(dbPath, STAR + IMG_TIF_TYPE)):
        print("Filename: ", filename)
        dest_img = cv2.imread(filename)  # read a new image
        ###dest_img = cv2.morphologyEx(dest_img, cv2.MORPH_CLOSE, kernel)  # clean image by morphology method
        mse_before_threshold = mse(source_img, dest_img)  # calculate MSE function
        print("MSE before threshold: ", mse_before_threshold)

        thresh_dest_img = findThreshold(dest_img)  # find threshold of current image in DB
        mse_after_threshold = mse(thresh_source_img, thresh_dest_img)  # calculate MSE function
        print("MSE after threshold: ", mse_after_threshold)

        print("index: ", i, "\n")
        i += 1
        #if i > 6:  # if condition to break loop due to runtime
        #    break
        print("----------------------------------------------")

        if mse_before_threshold < constants.THRESHOLD:
            match_img_list.append((filename, dest_img))  # thresh_dest_img

        continue  # break current iteration -prevents error of open-cv

    is_continue = True
    is_empty = False
    ###This if-else loop should be fixed!!!
    if len(match_img_list) < 1:  # if there is no match
        is_empty = True
        is_continue = bool(int(input("No match was found by MSE, do you want to continue?\n1 = Yes, 0 = No\n")))
    ###else:  # if found at least one image that may be matches

    if is_continue:
        if is_empty:
            database_files = glob.glob(os.path.join(DBpath, STAR + IMG_TIF_TYPE))
            database_files = database_files[:3]
            read_files = [cv2.imread(database_file) for database_file in database_files]
            match_img_list = list(zip(database_files, read_files))

        match_list = []  # define a list for matches
        stitcher = Stitcher()  # define a variable of Stitcher class

        i = 0

        for match_img in match_img_list:
            img_name, img_data = match_img
            imagesList = [source_img, img_data]  # thresh_source_img  # define a list of source and destination images to stitch
            # if mse_after_threshold-mse_before_threshold <= 0:
            # stitch the images together to create a panorama
            (result, vis) = stitcher.stitch(imagesList, showMatches=True)
            # else:
            #    result = None

            if not (result is None):  # if succeed to find matches between the two images
                print("Match was found.")
                # cv2.imshow("VIS", vis)
                scipy.misc.imsave(f'vis_{i}' + IMG_TYPE, vis)

                i += 1
                # cv2.imshow("result", result)  # show result image (for check)
                img = Image.fromarray(result, 'RGB')
                # img.show()
                img2 = trim(img)
                # img2.show()
                # cv2.waitKey(0)
                match_list.append(img_name)  # add filename to matches list
            else:
                print("There are not enough matches.")

        print(f"\nFound {len(match_list)} matches as follow:")
        for img_name in match_list:
            print(img_name)







def check_existance_by_stitcher(image, linkImages):
    stitcher = Stitcher()  # define a variable of Stitcher class
    source_img = cv2.imread(image)

    for linkId, linkImage_filename in linkImages:
        img = cv2.imread(linkImage_filename)  # read linked image from path
        #linkImage = numpy.empty_like(linkImage[0])
        #image = numpy.array(image)
        #print("Linked: ", linkImage, type(linkImage), type(image))
        imagesList = [source_img,
                      img]  # thresh_source_img  # define a list of source and destination images to stitch
        # if mse_after_threshold-mse_before_threshold <= 0:
        # stitch the images together to create a panorama
        (result, vis) = stitcher.stitch(imagesList, showMatches=True)
        # else:
        #    result = None

        if not (result is None):  # if succeed to find matches between the two images
            print("Match was found.")
            # cv2.imshow("VIS", vis)

            # cv2.imshow("result", result)  # show result image (for check)
            img = Image.fromarray(img, 'RGB')
            source_img = Image.fromarray(source_img)#, 'RGB')
            # img.show()
            #img2 = trim(img)
            # img2.show()
            # cv2.waitKey(0)
            return True, source_img, img, linkImage_filename, linkId
    #    else:
    #        print("There are not enough matches.")
    print("There are not enough matches.")
    return False, None, None, None, None












