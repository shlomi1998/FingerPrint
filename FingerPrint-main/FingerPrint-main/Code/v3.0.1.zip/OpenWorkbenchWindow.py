import tkinter as tk
from tkinter import ttk
from tkinter import filedialog, messagebox
import datetime
from PIL import Image, ImageTk, ImageEnhance, ImageFilter
import mysql
from tkinter import messagebox
from Server import check_existance_by_stitcher
from EditFunctions import *

HEIGHT = 650
WIDTH = 700

HEIGHT2 = 500
WIDTH2 = 500


def Main():
    root = tk.Tk()
    root.open_img = None

    canvas = tk.Canvas(root, height=HEIGHT, width=WIDTH)
    canvas.pack()

    frame_img = tk.Frame(root, borderwidth=1, relief='solid')  # frame to image, left side
    frame_img.place(relx=0.35, rely=0.05, relwidth=0.55, relheight=0.40)

    img_label = tk.Label(frame_img, image='')
    img_label.place(relx=0.1, rely=0.1, relwidth=0.8, relheight=0.8)
    root.nrotate = 0
    root.nalpha = 0
    root.brightness_img = 1.0
    root.sharpness_img = 0
    root.clean_noise_img = 0

    frame2 = tk.Frame(root)  # frame to button, right side
    frame2.place(relx=0.1, rely=0.05, relwidth=0.20, relheight=0.40)

    button_load_img = tk.Button(frame2, text="load image", font=40, command=load_img, bd=5)
    button_load_img.place(rely=0.02, relwidth=0.8, relheight=0.25)

    button2 = tk.Button(frame2, text="take a picture", font=10, command=rotate_img, bd=5)
    button2.place(rely=0.35, relwidth=0.8, relheight=0.25)

    button_reset = tk.Button(frame2, text="reset image", font=30, command=reset_image, bd=5)
    button_reset.place(rely=0.7, relwidth=0.8, relheight=0.25)

    frame3 = tk.Frame(root, bd=5, )  # frame to input finger and hands
    frame3.place(relx=0.08, rely=0.48, relwidth=0.2, relheight=0.35)

    frame4 = tk.Frame(root, )  # frame of scales
    frame4.place(relx=0.3, rely=0.45, relwidth=0.6, relheight=0.4)

    lower_frame = tk.Frame(root)  # lower frame for key buttons
    lower_frame.place(relx=0.1, rely=0.85, relwidth=0.82, relheight=0.12)

    label_hand = tk.Label(frame3, text='Finger:', )
    label_hand.place(relx=0.05, rely=0.05, relwidth=0.30, relheight=0.2)

    list_fingers = ttk.Combobox(frame3, values=[" thumb", " index finger",
                                                " middle finger", " ring finger",
                                                " little finger"])
    list_fingers.place(relx=0.4, rely=0.05, relwidth=0.60, relheight=0.2)

    label_hand = tk.Label(frame3, text='Hand:', )
    label_hand.place(relx=0.05, rely=0.5, relwidth=0.30, relheight=0.2)

    list_hand = ttk.Combobox(frame3, values=(" Right", " Left"))
    list_hand.place(relx=0.4, rely=0.5, relwidth=0.40, relheight=0.2)

    rotate_scale = tk.Scale(frame4, from_=0, to=360, orient='horizontal',
                            label="rotate image", command=update_rotate)
    rotate_scale.place(relx=0.05, rely=0.05, relwidth=0.95, relheight=0.2)

    brightness_scale = tk.Scale(frame4, from_=0.0, to=4.0, resolution=0.2, orient='horizontal', label="brightness",
                                command=update_brightness)
    brightness_scale.set(1.0)
    brightness_scale.place(relx=0.05, rely=0.29, relwidth=0.95, relheight=0.2)

    sharpness_scale = tk.Scale(frame4, from_=0.0, to=4.0, resolution=0.2, orient='horizontal', label="sharpness",
                               command=update_sharpness, )
    sharpness_scale.set(1.0)
    sharpness_scale.place(relx=0.05, rely=0.53, relwidth=0.95, relheight=0.2)
    noise_scale = tk.Scale(frame4, from_=0.0, to=3.0, resolution=0.05, orient='horizontal', label="clean noise",
                           command=update_clean_noise)
    noise_scale.set(0.0)
    noise_scale.place(relx=0.05, rely=0.77, relwidth=0.95, relheight=0.2)

    button_save = tk.Button(lower_frame, text="save in DB", font=30, command=save_image, bd=5)
    button_save.place(relx=0.05, rely=0.1, relwidth=0.35, relheight=0.7)

    button_fingerprint = tk.Button(lower_frame, text="Find match in DB", font=30, command=match_fingerprint, bd=5)
    button_fingerprint.place(relx=0.55, rely=0.1, relwidth=0.35, relheight=0.7)

    root.mainloop()  # display


if __name__ == "__main__":
    Main()
