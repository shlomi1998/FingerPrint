import datetime
#import MySQLdb
import csv
import pandas as pd
from xlsxwriter.workbook import Workbook

import pymysql
pymysql.install_as_MySQLdb()

# Open database connection
#db = MySQLdb.connect(
db = pymysql.connect(
    host="localhost",
    user="root",
    passwd="1234",
    db="db1"
   )

print(db)


cursor = db.cursor()


def close_db():
    global db
    db.close()
def find_date(date):
    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Date="{date}" AND users.ID=fingerprint.IdUser ;'

    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()

        if res == ():
            print("dont found")
        else:
            print(f"find date {date}\n")
            print(res)
        # Commit your changes in the database
        db.commit()
    except Exception as e:
        print("date dont found")
        print(str(e))

def find_hand(hand):
    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Hand="{hand}" AND users.ID=fingerprint.IdUser ;'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()

        if res == ():
            print("dont found")
        else:
            print(f"find hand {hand}\n")
            print(res)
        # Commit your changes in the database
        db.commit()
    except Exception as e:
     print(str(e))
def find_finger(finger):
    global db

    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Finger={finger} AND users.ID=fingerprint.IdUser ;'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()

        if res == ():
            print("dont found")
        else:
            print(f"find finger {finger}\n")
            print(res)
        # Commit your changes in the database
        db.commit()
    except Exception as e:
        print(str(e))
def find_finger_and_hand(hand,finger):
    global db
    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE fingerprint.Finger={finger} AND fingerprint.Hand="{hand}" AND users.ID=fingerprint.IdUser ;'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()
        if res==():
            print("dont found")
        else:
          print(f"find finger {finger} and hand {hand}\n")
          print(res)
        # Commit your changes in the database
        db.commit()

    except Exception as e:
        print(str(e))
def get_first_name(id):
    global db

    sql = f'SELECT FirstName FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res = cursor.fetchall()
        if res == ():
            print("dont found")
            return None
        else:
            print(f"find id {id}:\n")
            print(res)
            db.commit()
            return res[0][0]

        # Commit your changes in the database

    except Exception as e:
        print("id dont found")
        print(str(e))
def get_last_name(id):
    global db

    sql = f'SELECT LastName FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res = cursor.fetchall()
        if res == ():
            print("dont found")
            return None
        else:
            print(f"find id {id}:\n")
            print(res)
            db.commit()
            return res[0][0]

        # Commit your changes in the database

    except Exception as e:
        print("id dont found")
        print(str(e))
def find_id(id):
    global db

    sql = f'SELECT * FROM users,fingerprint' \
          f' WHERE users.ID={id} AND fingerprint.IdUser={id};'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()
        if res == ():
            print("dont found")
        else:
            print(f"find id {id}:\n")
            print(res)

        # Commit your changes in the database
        db.commit()
    except Exception as e:
        print("id dont found")
        print(str(e))
def delete_fingerprint(id):
    global db

    sql = f'DELETE FROM  db1.fingerprint WHERE IdUser={id};'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        # Commit your changes in the database
        db.commit()
    except Exception as e:
        print("error")
        print(str(e))
def delete_user(id):
    global db
    delete_fingerprint(id)
    sql=f'DELETE FROM db1.users WHERE ID={id};'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        # Commit your changes in the database
        print(f"user id={id} delete")
        db.commit()
    except Exception as e:
        print("error")
        print(str(e))
def create_user(id,first_name, last_name, gender):
    global db
    print(f'in mysql {id},{first_name}, {last_name}, {gender}')

    sql = f'INSERT INTO db1.users (ID, FirstName,LastName, Gender) VALUES  ("{int(id)}","{first_name}", "{last_name}","{gender}")'

    try:
        # Execute the SQL command
        cursor.execute(sql)
        # Commit your changes in the database
        db.commit()
        print("create new user\n")
        return 1
    except Exception as e:
        print(" error-create user\n")
        print(str(e))
        return 0


def add_fingerprint(iduser, hand, finger, date, time,link ,details):
    global db
    sql = f'INSERT INTO db1.fingerprint (IdUser, Hand, Finger, Date, Time,LinkImage,Details) VALUES ("{iduser}","{hand}", "{finger}", "{date}", "{time}","{link}" ,"{details}")'

    try:
        # Execute the SQL command
        cursor.execute(sql)
        # Commit your changes in the database
        db.commit()
        print("add_fingerprint")
        return 1
    except Exception as e:
        print(str(e))
        return 0



def print_all_users():
    num_row = cursor.execute('SELECT * FROM db1.users')
    print(num_row)
    results = cursor.fetchall()
    for row in results:
        id = row[0]
        first_name = row[1]
        last_name = row[2]
        gender = row[3]
        # hand = row[4]
        # finger = row[5]
        # data = row[6]
        # time = row[7]
        # code = row[8]
        # Now print fetched result
        print( f'id ={id},first_name={first_name},last_name={last_name},gender={gender}\n')
        # , hand = {hand}, finger = {finger}, data = {data}, time = {time}, code = {code}\n
        # ')


def save_tabels_in_excel():
    file_name='save db.xlsx'
    with pd.ExcelWriter(file_name) as writer:
        sql='SELECT * FROM db1.users'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer,sheet_name='users')
        # ------------------------
        sql = 'SELECT * FROM db1.fingerprint'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer, sheet_name='fingerprint')
        # ------------------------
        sql = 'SELECT * FROM db1.user_relationships'
        df = pd.read_sql_query(sql, db)
        df.to_excel(writer, sheet_name='user_relationships')
    # ------------------------
    print("save db in excel")




def get_all_fingerprints():
    global db
    sql = f'SELECT LinkImage FROM fingerprint ;'
    try:
        # Execute the SQL command
        cursor.execute(sql)
        res=cursor.fetchall()

        if res == ():
            print(f"Could not find linked images\n")
        else:
            print("Found all linked images\n")
            print(res)
        # Commit your changes in the database
        db.commit()
        return res
    except Exception as e:
     print(str(e))










# prepare a cursor object using cursor() method

# print(type(num_row))
# add_to_db(db,'22222222',"avi", 'levi', 'm', 'r', '4', '2019-06-04','13:10:00','333')
# add_to_db(db,'12345678', 'noa', 'levi', 'f', 'r', '4', '2019-06-04','18:10:00','222')


# create_user('55555', 'sdfg', 'levi', 'female')
# delete_user('55555')
# add_fingerprint(db,'2222','l', '1', '2019-06-04','18:10:00','','')
# find_finger(db,'4')
# find_hand(db,'r')
# find_id(db,'206221293')
# print_all_users()
# save_tabels_in_excel()
# delete_user(db,'2
# 222')
# find_hand(db,"l")
# find_finger_and_hand('r','4')
# #
# find_id("206221293")



# find_date(db,datetime.date(2019, 6, 4))

# print(datetime.date(2019, 6, 4))

# disconnect from server
# print(get_last_name('206221293'))




