import tkinter as tk
import requests
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import filedialog, messagebox
import datetime
from PIL import Image, ImageTk, ImageEnhance, ImageFilter
import mysql
from tkinter import messagebox


HEIGHT = 650
WIDTH = 700

HEIGHT2 = 500
WIDTH2 = 500

def MainApp():
    # class MainPage(tk.Frame):
    def documentation_creat_new_user(first_name,last_name,id,date,gender):
        file_name="documentation.txt"
        with open(file_name, "a") as text_file:
            text_file.write(f'Creat new user on: {date} \n:'
                            f'First name: {first_name}\n'
                            f'Last name: {last_name}\n'
                            f'ID: {id}\n'
                            f'Gender: {gender}\n'
                            f'------------------------------------------------------------------------\n')
        print(f'Documentation was saved in file name {file_name}')


    def documentation_fingerprint(first_name, last_name, id, date, time, hand, finger):
        img = root.save_image_name
        file_name = "documentation.txt"

        with open(file_name, "a") as text_file:
            text_file.write(f'Name: {first_name} {last_name} ID: {id}\n'
                            f'Date: {date} Time: {time}\n'
                            f'Image: {img} \n'
                            f'Math to: \n'
                            f'Hand: {hand}, finger:{finger}\n'
                            f'------------------------------------------------------------------------\n')
        print(f'Documentation was saved in file name {file_name}')

    def check_id_valid():
        """Checking for a control digit in the pipeline
    Multiply each digit except the last 1,2,1,2, ...
    If the multiplication exceeds 10, we will sum the digits
    We will sum up all the results of the multiplication
    And we will examine the complement to a multiplication of 10"""
        id=root.id_text.get()

        sum=0
        #
        for i in range(len(id)-1):
            if i%2 == 0:#Multiply by 1
                sum += int(id[i])

            else:#Multiply by 2
                num = int(id[i])*2
                # print(f'num={num}')
                if num >= 10:#If the multiplication exceeds 10, we will sum the digits
                    sum += num%10+num//10
                else:
                    sum += num

        # Completion of multiplication 10

        multiplication10=(sum//10+1)*10
        control_digit=multiplication10-sum
        if control_digit==int(id[-1]):#control digit is valid
            return 1
        else:
            return 0##control digit is NOT valid



    def ask_check_id():
        answer =tk.messagebox.askquestion("Delete", "Do you want to check if ID number is valid??", icon='warning')

        if answer == 'yes':
            valid = check_id_valid()
            if valid == 1:
                save_user()
            else:
                messagebox.showwarning("Information", "Invalid ID number, Please enter a valid ID")
                root.window_save_user.lift()
        else:
            save_user()


    def save_fingerprint(id):
        # add new fingerprint to db (by id)
        finger = list_fingers.get()

        hand = list_hand.get()
        date = datetime.datetime.now().date()
        time = datetime.datetime.now().time()
        link = root.save_image_name
        details = ""

        res = mysql.add_fingerprint(id, hand, finger, date, time, link, details)
        print(f'\nSave fingerprint: id: {id}, hand: {hand}, finger: {finger},'
              f' date: {date}, time: {time}, link: {link}, details: {details}')

        first_name = mysql.get_first_name(id)
        last_name = mysql.get_last_name(id)

        if res == 1:
            documentation_fingerprint(first_name, last_name, id, date, time, hand, finger)
            message = f'Save fingerprint in DB:\nid: {id}\nhand: {hand}\nfinger: {finger}' \
                f'\ndate: {date}\ntime: {time}\nlink: {link}\ndetails: {details}\n'
            messagebox.showwarning("Information", message)
        else:
            messagebox.showwarning("Information", "Error accured while saving fingerprint in FingerPrint table")


    def save_user():
    # create new user -add to db
        first_name = root.first_name_text.get()
        last_name = root.last_name_text.get()
        id = root.id_text.get()
        gender = root.list_gender.get(root.list_gender.curselection())

        res = mysql.create_user(id, first_name, last_name, gender)
        save_fingerprint(id)

        print(f'Save:\nfirst_name {first_name}, last_name {last_name}, id {id}, gender {gender}')
        date = datetime.datetime.now()
    #
        if res == 1:
          documentation_creat_new_user(first_name, last_name, id, date, gender)
          messagebox.showwarning("Information", f"save new user:{first_name} {last_name}")
        else:
          messagebox.showwarning("Information", "Error accured while saving user in Users table")
          root.window_save_user.destroy()


    def create_window_fingerprint():
        print("create_window_fingerprint")
        root.window_fingerprint = tk.Toplevel(root)
        canvas_window_fingerprint = tk.Canvas(root.window_fingerprint, height=HEIGHT, width=WIDTH)
        canvas_window_fingerprint.pack()

        frame_text = tk.Frame(root.window_fingerprint)  # frame to image, left side
        frame_text.place(relx=0, rely=0, relwidth=1, relheight=0.15)

        frame_images = tk.Frame(root.window_fingerprint)  # frame to image, left side
        frame_images.place(relx=0, rely=0.15, relwidth=1, relheight=0.4)

        frame_details = tk.Frame(root.window_fingerprint)  # frame to image, left side
        frame_details.place(relx=0, rely=0.55, relwidth=1, relheight=0.45)

        frame_user1 = tk.Frame(frame_details)  # frame to image, left side
        frame_user1.place(relx=0, rely=0, relwidth=0.5, relheight=1)

        frame_user2 = tk.Frame(frame_details)  # frame to image, left side
        frame_user2.place(relx=0.5, rely=0, relwidth=0.5, relheight=1)

        root.img_fingerprint1 = tk.Label(frame_images, image='')
        root.img_fingerprint1.place(relx=0.15, rely=0.05, relwidth=0.3, relheight=0.9)

        root.img_fingerprint2 = tk.Label(frame_images, image='')
        root.img_fingerprint2.place(relx=0.55, rely=0.05, relwidth=0.3, relheight=0.9)

        root.text_find_math = tk.Label(frame_text, text="", font=("Arial", 40))
        root.text_find_math.place(relx=0.5, rely=0.1, relwidth=0.8, relheight=0.8, anchor="n")

        root.details_user1 = tk.Label(frame_user1, text="", font=("Arial", 12), justify='left')
        root.details_user1.place(relx=0.5, rely=0, relwidth=0.8, relheight=0.8, anchor="n")

        root.details_user2 = tk.Label(frame_user2, text="", font=("Arial", 12), justify='left')
        root.details_user2.place(relx=0.5, rely=0, relwidth=0.8, relheight=0.8, anchor="n")


    def create_window_save_user():
        root.window_save_user = tk.Toplevel(root)
        canvas_new_window = tk.Canvas(root.window_save_user, height=HEIGHT2, width=WIDTH2)
        canvas_new_window.pack()

        frame_title= tk.Frame(root.window_save_user)  # frame to titel
        frame_title.place(relx=0, rely=0, relwidth=1, relheight=0.15)

        frame_img = tk.Frame(root.window_save_user)  # frame to image
        frame_img.place(relx=0, rely=0.15, relwidth=1, relheight=0.2)

        frame_window = tk.Frame(root.window_save_user)
        frame_window.place(relx=0, rely=0.35, relwidth=1, relheight=0.65)

        title = tk.Label(frame_title, text="Save user information in DB", font=("Arial", 16))
        title.place(relx=0.5, rely=0.1, relwidth=0.8, relheight=0.8, anchor="n")

        root.save_img_label = tk.Label(frame_img, image='')
        root.save_img_label.place(relx=0.5, rely=0.05,relwidth=0.5, relheight=0.95,anchor="n")

        # root.text_label = tk.Label(frame_window, text="",font=40)
        # root.text_label.place(relx=0.5, rely=0,relwidth=0.2, relheight=0.2,anchor="n")

        first_name_label= tk.Label(frame_window, text="First Name")
        first_name_label.place(relx=0.2, rely=0.1,relwidth=0.2, relheight=0.1,anchor="n")

        root.first_name_text = tk.Entry(frame_window, bd=5)
        root.first_name_text.place(relx=0.35, rely=0.1,relwidth=0.3, relheight=0.1)

        last_name_label = tk.Label(frame_window, text="Last Name")
        last_name_label.place(relx=0.2, rely=0.25, relwidth=0.2, relheight=0.1,anchor="n")

        root.last_name_text = tk.Entry(frame_window, bd=5)
        root.last_name_text.place(relx=0.35, rely=0.25, relwidth=0.3, relheight=0.1)

        id_label = tk.Label(frame_window, text="User ID")
        id_label.place(relx=0.2, rely=0.4, relwidth=0.2, relheight=0.1,anchor="n")

        root.id_text = tk.Entry(frame_window, bd=5)
        root.id_text.place(relx=0.35, rely=0.4, relwidth=0.3, relheight=0.1)

        gender_label = tk.Label(frame_window, text="Gender")
        gender_label.place(relx=0.2, rely=0.55, relwidth=0.3, relheight=0.1,anchor="n")
        root.list_gender = tk.Listbox(frame_window)

        root.list_gender.insert(1, "male")
        root.list_gender.insert(2, "female")
        root.list_gender.place(relx=0.35, rely=0.55, relwidth=0.3, relheight=0.1)

        button_save = tk.Button(frame_window, text="save new user", font=30, command=ask_check_id, bd=5)
        button_save.place(relx=0.47, rely=0.75, relwidth=0.25, relheight=0.1, anchor="n")


    def save_image_original_size():
        root.save_photo = Image.open(root.filename)
        root.save_photo = sharpness(brightness(root.save_photo, root.brightness_img), root.sharpness_img).rotate(root.nrotate)
        root.save_image_name = "results/"+root.filename.split("/")[-1]
        root.save_photo.save(root.save_image_name)


    def images_fingerprint(source_image, inDB_image):
        print("Print: ", type(root.save_photoimage2), type(inDB_image))
        ##root.img_fingerprint1.config(image=root.save_photoimage2)
        ##root.img_fingerprint2.config(image=root.save_photoimage2)
        root.img_fingerprint1.config(image=root.save_photoimage2)
        root.img_fingerprint2.config(image=inDB_image)

        text_window = "Match was found"
        text_user1 = 'Source image'
        text_user2 = 'Image in DB'

        root.text_find_math.config(text=text_window)
        root.details_user1.config(text=text_user1)
        root.details_user2.config(text=text_user2)


    def check_match_fingerprint():
        from Server import check_existance
        linkedImages = mysql.get_all_fingerprints()
        print("linked filename: ", linkedImages[0][0], type(linkedImages[0][0]))
        print("root filename: ", root.filename, type(root.filename))
        is_match, source_image, inDB_image = check_existance(root.filename, linkedImages)

        if is_match:
            create_window_fingerprint()
            save_image_original_size()
            save_img = root.save_photo.resize((200, 200), Image.ANTIALIAS)
            root.save_photoimage2 = ImageTk.PhotoImage(save_img)

            source_image = source_image.resize((200, 200), Image.ANTIALIAS)
            source_image = ImageTk.PhotoImage(source_image)

            inDB_image = inDB_image.resize((200, 200), Image.ANTIALIAS)
            inDB_image = ImageTk.PhotoImage(inDB_image)

            images_fingerprint(source_image, inDB_image)
        else:
            messagebox.showwarning("", "No match found")


    def match_fingerprint():
        if check_details_filled() == 1:
            check_match_fingerprint()


    def check_user_exists():
        pass


    def new_user():
        create_window_save_user()
        finger = list_fingers.get()
        hand = list_hand.get()
        # hand=list_hand.get(list_hand.curselection())
        # text_winsow="Details saved in DB:\n  finger: "+finger+"\n hand: "+hand
        #
        #
        # root.text_label.config(text=text_winsow)

        save_img = root.save_photo.resize((100, 100), Image.ANTIALIAS)

        root.save_photoimage = ImageTk.PhotoImage(save_img)

        root.save_img_label.config(image=root.save_photoimage)

    def fingerprint_id_math():
        return None
        # return '206221293'

    def check_details_filled():#Check if  filled out the details
        if root.open_img is None:  # If there is no picture, show error message
            messagebox.showwarning("Warning", "No image")
            return False
        elif (list_hand.current() == -1):
            messagebox.showwarning("Warning", "You didn't select a hand")
            return 0
        elif (list_fingers.current() == -1):
            messagebox.showwarning("Warning", "You didn't select a finger")
            return 0
        else:
            return 1


    def save_image():
      # print(print(f'current={list_hand.current()}  get={list_hand.get()}'))
      print("In save_image")

      if check_details_filled() == 1:

          id_math =fingerprint_id_math()#call to func find math and return the id of the math fingerprint
          save_image_original_size()
          if id_math !=None:  # if found math(user user exists-),save only the finger print
              save_fingerprint(id_math)
          else:  # if not found math,open window to creat a new user
              new_user( )


    def reset_parameters():
        root.temp_img = None
        root.brightness_img = 1.0
        root.sharpness_img = 1.0
        root.nrotate = 0
        rotate_scale.set(0)
        brightness_scale.set(1.0)
        sharpness_scale.set(1.0)

    def reset_image():
        reset_parameters()
        root.open_img = root.original_img
        root.image_tk = ImageTk.PhotoImage(root.open_img)
        img_label.configure(image=root.image_tk)

    def load_img():
        root.filename = filedialog.askopenfilename(title='Choose a fingerprint')
        if len(root.filename) > 0:
            reset_parameters()
            root.open_img = Image.open(root.filename)
            root.open_img = root.open_img.resize((200, 200), Image.ANTIALIAS)
            root.temp_img = None
            root.original_img = root.open_img  # save original image for reset
            root.image_tk = ImageTk.PhotoImage(root.open_img)

            img_label.configure(image=root.image_tk)
        else:
            pass

    def brightness(img, val):  # change the brightness of image by value
        enhancer = ImageEnhance.Sharpness(img)
        return enhancer.enhance(val)


    def sharpness(img,val):#change the sharpness of image by value
        enhancer = ImageEnhance.Brightness(img)
        return enhancer.enhance(val)


    def update_img():#The function updates all changes to the image:,rotate,sharpness,brightness
        root.temp_img=sharpness(brightness(root.open_img,root.brightness_img),root.sharpness_img).rotate(root.nrotate)

        root.image_tk = ImageTk.PhotoImage(root.temp_img)
        img_label.configure(image=root.image_tk)


    def  rotate_img(value=None):
        if value is None:
            messagebox.showwarning("Warning", "This function does not work yet!")
        else:
            root.nrotate = value
            update_img()


    def brightness__img(value):
        root.brightness_img = value
        update_img()


    def sharpness_img(value):
        root.sharpness_img =value

        update_img()


    def clean_noise_img(value=None):
        messagebox.showwarning("Warning", "This function does not work yet!")
        '''
        root.clean_noise_img = value
        inverted_image = root.open_img.filter(ImageFilter.GaussianBlur(radius=root.clean_noise_img))
        root.image_tk = ImageTk.PhotoImage(inverted_image)
        img_label.configure(image=root.image_tk)
        # update_img()
        '''


    def update_rotate(value):
        if root.open_img is None:
            messagebox.showwarning("Warning", "No image")
            rotate_scale.set(0)
        else:
            rotate_img(int(value))


    def update_brightness(value):
        if root.open_img is None and float(value) != 1.0:  # If there is no picture, an error message
            messagebox.showwarning("Warning", "No image")
            brightness_scale.set(1.0)
        elif root.open_img is None and float(value) == 1.0:  # If this is the first time that the window opens, do nothing
            return
        else:
             brightness__img(float(value))


    def update_sharpness(value):
        if root.open_img is None and float(value) != 1.0:  # If there is no picture, an error message
            messagebox.showwarning("Warning", "no image")
            sharpness_scale.set(1.0)
        elif root.open_img is None and float(value) == 1.0:  # If this is the first time that the window opens, do nothing
            return
        else:
            sharpness_img(float(value))


    def update_clean_noise(value):
        if root.open_img is None and float(value) != 1.0:  # If there is no picture, an error message
            messagebox.showwarning("Warning", "No image")
            sharpness_scale.set(1.0)
        elif root.open_img is None and float(value) == 1.0:  # If this is the first time that the window opens, do nothing
            return
        else:
            clean_noise_img(float(value))


    root = tk.Tk()

    root.open_img=None


    canvas =tk.Canvas(root, height=HEIGHT, width=WIDTH)
    canvas.pack()

    # background_image=tk.PhotoImage(file='images\p4.png',height=HEIGHT, width=WIDTH)
    # background_label=tk.Label(root,image=background_image)
    # background_label.place(relwidth=1, relheight=1)

    frame_img=tk.Frame(root, borderwidth = 1,relief='solid')#frame to image, left side
    frame_img.place(relx=0.35, rely=0.05,relwidth=0.55, relheight=0.40)

    img_label = tk.Label(frame_img, image='')
    img_label.place(relx=0.1, rely=0.1,relwidth=0.8, relheight=0.8)
    root.nrotate = 0
    root.nalpha = 0
    root.brightness_img = 1.0
    root.sharpness_img = 0
    root.clean_noise_img = 0

    frame2 = tk.Frame(root)#frame to button, right side
    frame2.place(relx=0.1, rely=0.05, relwidth=0.20, relheight=0.40)

    button_load_img = tk.Button(frame2, text="load image", font=40, command=load_img, bd=5)
    button_load_img.place(rely=0.02, relwidth=0.8, relheight=0.25)

    button2 = tk.Button(frame2, text="take a picture", font=10, command=rotate_img, bd=5)
    button2.place(rely=0.35, relwidth=0.8, relheight=0.25)

    button_reset = tk.Button(frame2, text="reset image", font=30, command=reset_image, bd=5)
    button_reset.place(rely=0.7, relwidth=0.8, relheight=0.25)
    # button_load_img=tk.Button(frame2,text="load imge",font=40,command=load_img)
    # button_load_img.place(rely=0.02, relwidth=0.8, relheight=0.3)
    #
    #
    # button2=tk.Button(frame2,text="take a picture",font=10,command=rotate_img)
    # button2.place(rely=0.5, relwidth=0.8, relheight=0.3)

    frame3 = tk.Frame(root, bd=5,)#frame to input finger and hands
    frame3.place(relx=0.08, rely=0.48, relwidth=0.2, relheight=0.35)

    frame4 = tk.Frame(root,)#frame of scalas
    frame4.place(relx=0.3, rely=0.45, relwidth=0.6, relheight=0.4)

    lower_frame = tk.Frame(root)#Lower frame for key buttons
    lower_frame.place(relx=0.1, rely=0.85, relwidth=0.82, relheight=0.12)
    # lower_frame=tk.Frame(root)#Lower frame for key buttons
    # lower_frame.place(relx=0.1, rely=0.85,relwidth=0.82, relheight=0.12)

    label_hand = tk.Label(frame3, text='finger:',)
    label_hand.place(relx=0.05, rely=0.05, relwidth=0.30, relheight=0.2)

    # list_fingers = tk.Spinbox(frame3, values=(" thumb"," index finger"," middle finger"," ring finger"," little finger"))
    # list_fingers.place(relx=0.4, rely=0.05,relwidth=0.60, relheight=0.2)

    list_fingers = ttk.Combobox(frame3, values=[" thumb", " index finger",
                                                " middle finger", " ring finger", " little finger"])
    list_fingers.place(relx=0.4, rely=0.05, relwidth=0.60, relheight=0.2)

    label_hand = tk.Label(frame3, text='hand:',)
    label_hand.place(relx=0.05, rely=0.5, relwidth=0.30, relheight=0.2)

    # list_hand = tk.Spinbox(frame3, values=("Right","Left"))
    # list_hand.place(relx=0.4, rely=0.5,relwidth=0.40, relheight=0.2)
    list_hand = ttk.Combobox(frame3, values=(" Right", " Left"))
    list_hand.place(relx=0.4, rely=0.5,relwidth=0.40, relheight=0.2)

    rotate_scale = tk.Scale(frame4, from_=0, to=360, orient='horizontal', label="rotate image", command=update_rotate)
    rotate_scale.place(relx=0.05, rely=0.05, relwidth=0.95, relheight=0.2)

    brightness_scale = tk.Scale(frame4, from_=0.0, to=4.0, resolution=0.2, orient='horizontal', label="sharpness", command=update_brightness)
    brightness_scale.set(1.0)
    brightness_scale.place(relx=0.05, rely=0.29, relwidth=0.95, relheight=0.2)

    sharpness_scale = tk.Scale(frame4, from_=0.0, to=4.0, resolution=0.2, orient='horizontal', label="brightness", command=update_sharpness,)
    sharpness_scale.set(1.0)
    sharpness_scale.place(relx=0.05, rely=0.53, relwidth=0.95, relheight=0.2)
    noise_scale = tk.Scale(frame4, from_=0.0, to=3.0, resolution=0.05, orient='horizontal', label="clean noise", command=update_clean_noise)
    noise_scale.set(0.0)
    noise_scale.place(relx=0.05, rely=0.77, relwidth=0.95, relheight=0.2)

    # rotate_scale = tk.Scale(frame4, from_=0, to=360,orient='horizontal',label="rotate image",command=update_rotate)
    # rotate_scale.place(relx=0.05,rely=0.05,relwidth=0.8, relheight=0.3)
    #
    # brightness_scale = tk.Scale(frame4, from_=0.0, to=4.0,resolution=0.2,orient='horizontal',label="sharpness",command=update_brightness)
    # brightness_scale.set(1.0)
    # brightness_scale.place(relx=0.05,rely=0.3,relwidth=0.8, relheight=0.3)
    #
    # sharpness_scale = tk.Scale(frame4, from_=0.0, to=4.0,resolution=0.2,orient='horizontal',label="brightness",command=update_sharpness,)
    # sharpness_scale.set(1.0)
    # sharpness_scale.place(relx=0.05,rely=0.6,relwidth=0.8, relheight=0.3)

    button_save = tk.Button(lower_frame, text="save in DB ", font=30, command=save_image, bd=5)
    button_save.place(relx=0.05, rely=0.1, relwidth=0.35, relheight=0.7)

    button_Fingerprint = tk.Button(lower_frame, text="Find match", font=30, command=match_fingerprint, bd=5)
    button_Fingerprint.place(relx=0.55, rely=0.1,relwidth=0.35, relheight=0.7)

    # button_reset=tk.Button(lower_frame,text="reset image",font=30,command=reset_image,bd=5)
    # button_reset.place(relx=0.7, rely=0.05,relwidth=0.25, relheight=0.8)

    # Displaying it

    root.mainloop()


if __name__ == "__main__":
    MainApp()
